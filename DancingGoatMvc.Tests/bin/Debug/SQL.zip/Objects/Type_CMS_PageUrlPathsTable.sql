CREATE TYPE [dbo].[Type_CMS_PageUrlPathsTable] AS TABLE(
	[CultureCode] [nvarchar](50) NOT NULL,
	[UrlPath] [nvarchar](2000) NOT NULL
)
GO
